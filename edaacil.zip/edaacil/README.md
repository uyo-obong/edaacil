# Edaacil Project

Edacil is a web application that will keep track of insurance documents and issue out insurance certificates to vehicle owners in order to  ensure safety and soundness of policyholders.

