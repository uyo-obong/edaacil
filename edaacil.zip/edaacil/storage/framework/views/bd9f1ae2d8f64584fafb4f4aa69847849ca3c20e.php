<?php $__env->startSection('content'); ?>
    <center class="wrapper">
        <div class="webkit">
            <!--[if (gte mso 9)|(IE)]>
            <table width="600" align="center">
                <tr>
                    <td>
            <![endif]-->
            <table class="outer" align="center">
                <tr>
                    <td class="one-column">
                        <table width="100%">
                            <tr>
                                <td class="inner contents">
                                    <p>Hi <?php echo e($manager->fullName()); ?></p>
                                    <p>
                                        We are pleased to welcome you as an Agent of Edaacil Cooperative Insurance Limited. We feel honored that you have choose to work with us, and we are eager to work with you.

                                    </p>

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="two-column">
                        <div class="column">
                            <table width="100%">
                                <tr>
                                    <td class="inner">
                                        <table class="contents">
                                            <tr>
                                                <td>
                                                    <a class="button" href="<?php echo e(route('agent.auth.login')); ?>">Login Here</a>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </div>

                    </td>
                </tr>
                <tr>
                    <td class="one-column">
                        <table width="100%">
                            <tr>
                                <td class="inner contents">
                                    <br>
                                    <p>We look forward to a long and successful association. Kindly use the details below to login to your account:- </p>
                                    <p>Email: <?php echo e($manager['email']); ?></p>
                                    <p>Password: <?php echo e($password); ?></p>
                                </td>
                            </tr>
                        </table>

                    </td>
                </tr>

                <tr>
                    <td class="one-column">
                        <table width="100%">
                            <tr>
                                <td class="inner contents">
                                    <br>
                                    <p>Edaacil Team</p>
                                </td>
                            </tr>
                        </table>

                    </td>
                </tr>

            </table>

        </div>
    </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/legendary/Projects/edaacil/resources/views/emails/welcome.blade.php ENDPATH**/ ?>