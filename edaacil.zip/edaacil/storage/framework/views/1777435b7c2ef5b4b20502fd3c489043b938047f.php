<script>
<?php if( Session::has('success') || Session::has('danger') ): ?>
    var notify = $.notify('<strong>Processing:</strong> Do not close this page...', {
    allow_dismiss: false,
    showProgressbar: true
    });

    setTimeout(function() {
    notify.update({'type': '<?php echo e(Session::has('success') ? 'success' : 'danger'); ?>', 'message': '<?php echo e(Session::get("success") ?: Session::get("danger")); ?>', 'progress': 20});
    }, 100);
    <?php
        Session::forget('success');
        Session::forget('danger');
    ?>
<?php endif; ?>
</script><?php /**PATH /home/legendary/Projects/edaacil/Modules/Manager/Resources/Views/utiles/notifications/notify.blade.php ENDPATH**/ ?>