<?php $__env->startSection('title', 'Manager Account'); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="body_scroll">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-7 col-md-6 col-sm-12">
                        <h2>Manage Account</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/manager"><i class="zmdi zmdi-home"></i> Edaacil</a></li>
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Account</a></li>
                            <li class="breadcrumb-item active">List</li>
                        </ul>
                        <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                    </div>
                    <div class="col-lg-5 col-md-6 col-sm-12">
                        <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>
                        <button class="btn btn-success btn-icon float-right waves-effect" data-toggle="modal" data-target="#addAccountModal" type="button"><i class="zmdi zmdi-plus"></i></button>
                    </div>
                </div>
            </div>

            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                        <thead>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Phone No.</th>
                                            <th>Status</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tfoot>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Phone No.</th>
                                            <th>Status</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                        </tfoot>
                                        <tbody>
                                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->index + 1); ?></td>
                                                <td><?php echo e($account->fullName()); ?></td>
                                                <td><?php echo e($account->email); ?></td>
                                                <td><?php echo e($account->phone_no); ?></td>
                                                <td><a class="<?php echo e($account->status == 'Active' ? 'badge-success' : 'badge-danger'); ?>" href="" > <?php echo e($account->status); ?></a></td>
                                                <td><?php echo e($account->role); ?></td>
                                                <td> <?php echo $__env->make('manager::account.buttons.view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  <?php echo $__env->make('manager::account.buttons.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('manager::account.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('manager::account.edit_account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('manager::account.view_account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#editAccountModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var accountId = button.data('id');
            var email = button.data('email');
            var status = button.data('status');

            var modal = $(this);
            modal.find('.modal-body #accountId').val(accountId);
            modal.find('.modal-body #email').val(email);
            modal.find('.modal-body #status').val(status).change();
        });
    </script>

    <script>
        $('#viewAccountModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var fullName = button.data('name');
            var role = button.data('role');
            var email = button.data('email');
            var phone_no = button.data('phone_no');
            var address = button.data('address');
            var city = button.data('city');
            var state = button.data('state');
            var country = button.data('country');

            var modal = $(this);
            modal.find('.modal-body #fullName').text(fullName);
            modal.find('.modal-body #role').text('Edaacil '+role);
            modal.find('.modal-body #email').text(email);
            modal.find('.modal-body #phone_no').text(phone_no);
            modal.find('.modal-body #address').text(address);
            modal.find('.modal-body #city').text(city);
            modal.find('.modal-body #state').text(state);
            modal.find('.modal-body #country').text(country);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('manager::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/legendary/Projects/edaacil/Modules/Manager/Resources/Views/account/list.blade.php ENDPATH**/ ?>