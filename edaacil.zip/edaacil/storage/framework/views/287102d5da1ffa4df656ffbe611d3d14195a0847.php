<?php $__env->startSection('title', 'Agent Dashboard'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>Manage Certificates</h2>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <!-- Basic Examples -->
            <div class="row clearfix">
                <?php if ($__env->exists('agent::data.agent')) echo $__env->make('agent::data.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-8">
                    <div class="card">

                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Token</th>
                                        <th>Holder</th>
                                        <th>Day</th>
                                        <th>Month</th>
                                        <th>Year</th>
                                    </tr>
                                    </thead>
                                    <tfoot>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Token</th>
                                        <th>Holder</th>
                                        <th>Day</th>
                                        <th>Month</th>
                                        <th>Year</th>
                                    </tr>
                                    </tfoot>
                                    <tbody>
                                    <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e(isset($certificate->token['token']) ? $certificate->token['token'] : ""); ?></td>
                                            <td><?php echo e($certificate->name_of_policy_holder); ?></td>
                                            <td><?php echo e($certificate->created_at->format('d')); ?></td>
                                            <td><?php echo e($certificate->created_at->format('M')); ?></td>
                                            <td><?php echo e($certificate->created_at->format('Y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agent::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/edaacilc/public_html/edaacil/Modules/Agent/Resources/Views/dashboard.blade.php ENDPATH**/ ?>