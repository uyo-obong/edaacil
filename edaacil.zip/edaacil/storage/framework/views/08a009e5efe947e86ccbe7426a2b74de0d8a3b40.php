<?php $__env->startSection('title', 'Agent Dashboard'); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/plugins/dropify/css/dropify.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>Profile</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/agent"><i class="zmdi zmdi-home"></i> Dashboard</a></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row clearfix">
                <div class="col-lg-4 col-md-12">
                    <div class="card mcard_4">
                        <div class="body">
                            <div class="img">
                                <img src="<?php echo e(URL::to('assets/images/lg/avatar2.jpg')); ?>" class="rounded-circle" alt="profile-image">
                            </div>
                            <div class="user">
                                <h5 class="mt-3 mb-1"><?php echo e($agent->fullName()); ?></h5>
                                <small class="text-muted"><?php echo e($agent->email); ?></small>
                                <div class="progress-container progress-success">
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="body">
                            <small class="text-muted">Email address: </small>
                            <p><?php echo e($agent->email); ?></p>
                            <hr>
                            <small class="text-muted">Phone: </small>
                            <p><?php echo e($agent->phone_number); ?></p>
                            <hr>
                            <small class="text-muted">Address: </small>
                            <p><?php echo e($agent->address); ?></p>
                            <hr>
                            <small class="text-muted">City: </small>
                            <p><?php echo e($agent->city); ?></p>
                            <hr>
                            <small class="text-muted">State: </small>
                            <p><?php echo e($agent->state); ?></p>
                            <hr>

                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12">
                    <div class="card">
                        <div class="body">
                            <?php if ($__env->exists('agent::data.edit_profile')) echo $__env->make('agent::data.edit_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(URL::to('assets/plugins/dropify/js/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('assets/js/pages/forms/dropify.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('agent::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/legendary/Projects/edaacil/Modules/Agent/Resources/Views/data/profile.blade.php ENDPATH**/ ?>