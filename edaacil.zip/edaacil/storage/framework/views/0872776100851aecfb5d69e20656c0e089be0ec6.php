<?php $__env->startSection('title', 'Edit Profile'); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="body_scroll">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-7 col-md-6 col-sm-12">
                        <h2>Profile Edit</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/manager"><i class="zmdi zmdi-home"></i> Edaacil</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.account.list')); ?>">Account</a></li>
                            <li class="breadcrumb-item active"><a href="<?php echo e(route('manager.account.profile')); ?>">Profile</a></li>
                            <li class="breadcrumb-item active">Edit</li>
                        </ul>
                        <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                    </div>
                    <div class="col-lg-5 col-md-6 col-sm-12">
                        <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>

                    </div>
                </div>
            </div>

            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h2><strong>Security</strong> Settings</h2>
                            </div>
                            <div class="body">
                                <form id="form_validation" method="post" action="<?php echo e(route('manager.account.manager.change.password')); ?>" enctype="multipart/form-data">
                                    <?php echo e(method_field('PUT')); ?>

                                    <div class="row">
                                        <div class="file-name">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="hidden" value="<?php echo e($manager->id); ?>" name="managerId">
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <input type="email" name="email" class="form-control" placeholder="Enter Your Email" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <input type="password" name="password" class="form-control" placeholder="New Password" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <input type="password" name="password_confirmation" class="form-control" placeholder="Retype Password" required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit" class="float-right btn btn-info">Save Changes</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="card">
                            <div class="header">
                                <h2><strong>Account</strong> Settings</h2>
                            </div>
                            <div class="body">
                                <form id="form_validation" method="post" action="<?php echo e(route('manager.account.manager.update.profile')); ?>" enctype="multipart/form-data">
                                    <?php echo e(method_field('PUT')); ?>

                                    <div class="row clearfix">

                                        <div class="col-lg-12 col-md-12">
                                            <div class="row">
                                                <div class="col-lg-4 col-md-4">
                                                    <div class="card">
                                                        <a href="javascript:void(0);" class="file">
                                                            <div class="image">
                                                                <img src="<?php echo e(auth()->user()
                    ->profile_image != '' ? '/storage/'.auth()->user()->profile_image : URL::to ('default_avatar.png')); ?>">
                                                            </div>
                                                            <div class="file-name">
                                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                                <input type="hidden" value="<?php echo e($manager->id); ?>" name="managerId">
                                                                <input type="file" class="file" name="profile_image" value="<?php echo e($manager->profile_image); ?>">
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>

                                                <div class="col-lg-8 col-md-8">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="<?php echo e($manager->last_name); ?>" name="last_name" placeholder="Last Name">
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-md-6">
                                                                <div class="form-group">
                                                                <input type="text" class="form-control" value="<?php echo e($manager->first_name); ?>" name="first_name" placeholder="First Name" required>
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="form-group">
                                                                <input type="email" class="form-control" value="<?php echo e($manager->email); ?>" name="email" placeholder="Email Address" required>
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="<?php echo e($manager->phone_no); ?>" name="phone_no" placeholder="Phone Number">
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-12 col-md-12">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" value="<?php echo e($manager->address); ?>" name="address" placeholder="Address">
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-4 col-md-4">
                                                            <div class="form-group">
                                                                <input  type="text" class="form-control" value="<?php echo e($manager->city); ?>" name="city" placeholder="City" required>
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-4 col-md-4">
                                                            <div class="form-group">
                                                                <input  type="text" class="form-control" value="<?php echo e($manager->state); ?>" name="state" placeholder="State" required>
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-4 col-md-4">
                                                            <div class="form-group">
                                                                <input  type="text" class="form-control" value="<?php echo e($manager->country); ?>" name="country" placeholder="Country" required>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <button type="submit" class="float-right btn btn-primary">Save Changes</button>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(URL::to('assets/plugins/dropify/js/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('assets/js/pages/forms/dropify.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('manager::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/edaacilc/public_html/edaacil/Modules/Manager/Resources/Views/account/edit_profile.blade.php ENDPATH**/ ?>