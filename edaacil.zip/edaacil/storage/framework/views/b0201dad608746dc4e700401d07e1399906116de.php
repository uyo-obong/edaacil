<!doctype html>
<html class="no-js " lang="en">
<head>
    <title>Edaacil - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon-->
    <link rel="icon" href="<?php echo e(URL::to('favicon.ico')); ?>" type="image/x-icon">
    <!-- Custom Css -->
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>">
    <link href="<?php echo e(URL::to('assets/plugins/bootstrap-select/css/bootstrap-select.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/css/style.min.css')); ?>">
    <!-- JQuery DataTable Css -->
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/plugins/jquery-datatable/dataTables.bootstrap4.min.css')); ?>">
    <style>
        .content {
            margin: 0px 40px 0px 40px !important;
        }
    </style>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="theme-blush">

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<!-- Main Content -->
<section class="content">
    <?php echo $__env->yieldContent('content'); ?>
</section>

</body>
<!-- Jquery Core Js -->
<script src="<?php echo e(URL::to('assets/bundles/libscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(URL::to('assets/bundles/vendorscripts.bundle.js')); ?>"></script><!-- Lib Scripts Plugin Js -->

<!-- Jquery DataTable Plugin Js -->
<script src="<?php echo e(URL::to('assets/bundles/datatablescripts.bundle.js')); ?>"></script>
<script src="<?php echo e(URL::to('assets/plugins/jquery-datatable/buttons/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(URL::to('assets/plugins/jquery-datatable/buttons/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::to('assets/plugins/jquery-datatable/buttons/buttons.print.min.js')); ?>"></script>

<script src="<?php echo e(URL::to('assets/js/pages/tables/jquery-datatable.js')); ?>"></script>

<script src="<?php echo e(URL::to('assets/plugins/jquery-validation/jquery.validate.js')); ?>"></script> <!-- Jquery Validation Plugin Css -->
<script src="<?php echo e(URL::to('assets/js/pages/forms/form-validation.js')); ?>"></script>

<script src="<?php echo e(URL::to('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js')); ?>"></script> <!-- Bootstrap Colorpicker Js -->
<script src="<?php echo e(URL::to('assets/plugins/jquery-inputmask/jquery.inputmask.bundle.js')); ?>"></script> <!-- Input Mask Plugin Js -->
<script src="<?php echo e(URL::to('assets/js/pages/forms/advanced-form-elements.js')); ?>"></script>

<script src="<?php echo e(URL::to('assets/plugins/bootstrap-notify/bootstrap-notify.js')); ?>"></script> <!-- Bootstrap Notify Plugin Js -->
<?php echo $__env->make('manager::utiles.notifications.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
</html>
<?php /**PATH /home/edaacilc/public_html/edaacil/Modules/Agent/Resources/Views/layouts/master.blade.php ENDPATH**/ ?>