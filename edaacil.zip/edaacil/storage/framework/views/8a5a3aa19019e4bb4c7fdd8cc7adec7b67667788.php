<?php $__env->startSection('title', 'Manager Profile'); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="body_scroll">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-7 col-md-6 col-sm-12">
                        <h2>Profile</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/manager"><i class="zmdi zmdi-home"></i> Edaacil</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('manager.account.list')); ?>">Account</a></li>
                            <li class="breadcrumb-item active">Profile</li>
                        </ul>
                        <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                    </div>
                    <div class="col-lg-5 col-md-6 col-sm-12">
                        <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>
                        <a href="<?php echo e(route('manager.account.edit.profile')); ?>" class="btn btn-info btn-icon float-right"><i class="zmdi zmdi-edit"></i></a>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-12">
                        <div class="card mcard_3">
                            <div class="body">
                                <a href="#"><img src="<?php echo e(auth()->user()
                    ->profile_image != '' ? '/storage/'.auth()->user()->profile_image : URL::to ('default_avatar.png')); ?>" class="rounded-circle shadow " alt="profile-image"></a>
                                <h4 class="m-t-10"><?php echo e(auth()->user()->fullName()); ?></h4>
                                <div class="row">
                                    <div class="col-12">
                                        <p class="text-muted"><?php echo e(auth()->user()->role); ?> Edaacil — <?php echo e(auth()->user()->country); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="body">
                                <small class="text-muted">Email address: </small>
                                <p><?php echo e(auth()->user()->email); ?></p>
                                <hr>
                                <small class="text-muted">Phone: </small>
                                <p><?php echo e(auth()->user()->phone_number); ?></p>
                                <hr>
                                <small class="text-muted">Address: </small>
                                <p><?php echo e(auth()->user()->address); ?></p>
                                <hr>
                                <small class="text-muted">City: </small>
                                <p><?php echo e(auth()->user()->city); ?></p>
                                <hr>
                                <small class="text-muted">State: </small>
                                <p><?php echo e(auth()->user()->state); ?></p>
                                <hr>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12">
                        <div class="card">
                            <div class="body">
                                <div id="calendar"></div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/edaacilc/public_html/edaacil/Modules/Manager/Resources/Views/account/profile.blade.php ENDPATH**/ ?>