<?php

namespace Edaacil\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application webservices.
     *
     * @return void
     */
    public function register()
    {

    }

    /**
     * Bootstrap any application webservices.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
